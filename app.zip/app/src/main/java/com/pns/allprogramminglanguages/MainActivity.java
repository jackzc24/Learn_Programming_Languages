package com.pns.allprogramminglanguages;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView c = findViewById(R.id.c);
        ImageView c_plus = findViewById(R.id.c_plus);
        ImageView java = findViewById(R.id.java);
        ImageView kotlin = findViewById(R.id.kotlin);
        ImageView python = findViewById(R.id.python);
        ImageView ai = findViewById(R.id.android);

        c.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            intent.putExtra("title", "C");
            startActivity(intent);
        });

        c_plus.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            intent.putExtra("title", "C++");
            startActivity(intent);
        });

        java.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            intent.putExtra("title", "Java");
            startActivity(intent);
        });

        kotlin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            intent.putExtra("title", "Kotlin");
            startActivity(intent);
        });

        python.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            intent.putExtra("title", "Python");
            startActivity(intent);
        });

        ai.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            intent.putExtra("title", "Android");
            startActivity(intent);
        });
    }
}