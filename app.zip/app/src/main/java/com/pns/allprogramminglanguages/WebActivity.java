package com.pns.allprogramminglanguages;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Objects;

public class WebActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar mProgressBar;
    private ProgressBar progressBar;
    private ImageView refresh;
    private int i;
    private CountDownTimer timer;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        Toolbar toolbar = findViewById(R.id.tool);
        setSupportActionBar(toolbar);

        mProgressBar = findViewById(R.id.pp);
        refresh = findViewById(R.id.refresh);
        TextView title = findViewById(R.id.webTitle);
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.webProgress);
        progressBar.setMax(100);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        title.setText(getIntent().getStringExtra("title"));

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.getSettings().setAppCacheEnabled(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setSaveFormData(true);
        webView.getSettings().setAllowFileAccess(true);

        webView.loadUrl(getIntent().getStringExtra("url"));
        webView.setWebViewClient(new webViewClient());
        webView.setWebChromeClient(new ChromeClient());

        progressBar.setProgress(0);

        refresh.setOnClickListener(v -> {

            if (isNotNetworkAvailable()) {

                if (getApplicationContext() != null)
                    Toast.makeText(WebActivity.this, "No Internet Connection ", Toast.LENGTH_LONG).show();

            } else {

                refresh.setVisibility(View.INVISIBLE);
                mProgressBar.setVisibility(View.VISIBLE);
                webView.reload();
                i = 0;
            }

            new Handler().postDelayed(() -> {

                refresh.setVisibility(View.VISIBLE);
                mProgressBar.setVisibility(View.GONE);
            }, 2000);
        });
    }

    private static class webViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            view.loadUrl(url);
            return true;
        }
    }

    private class ChromeClient extends WebChromeClient {
        private View mCustomView;
        private WebChromeClient.CustomViewCallback mCustomViewCallback;
        private int mOriginalOrientation;
        private int mOriginalSystemUiVisibility;

        ChromeClient() {
        }

        public Bitmap getDefaultVideoPoster() {
            if (mCustomView == null) {
                return null;
            }
            return BitmapFactory.decodeResource(getApplicationContext().getResources(), 2130837573);
        }

        public void onHideCustomView() {
            ((FrameLayout) getWindow().getDecorView()).removeView(this.mCustomView);
            this.mCustomView = null;
            getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
            setRequestedOrientation(this.mOriginalOrientation);
            this.mCustomViewCallback.onCustomViewHidden();
            this.mCustomViewCallback = null;
        }

        public void onShowCustomView(View paramView, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
            if (this.mCustomView != null) {
                onHideCustomView();
                return;
            }
            this.mCustomView = paramView;
            this.mOriginalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
            this.mOriginalOrientation = getRequestedOrientation();
            this.mCustomViewCallback = paramCustomViewCallback;
            ((FrameLayout) getWindow().getDecorView()).addView(this.mCustomView, new FrameLayout.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(3846 | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {

            if (isNotNetworkAvailable()) {

                progressBar.setVisibility(View.INVISIBLE);

                if (i == 0) {

                    i++;

                    if (getApplicationContext() != null)
                        Toast.makeText(WebActivity.this, "No Internet Connection ", Toast.LENGTH_LONG).show();

                    timer = new CountDownTimer(10000, 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {

                            if (!isNotNetworkAvailable()) {

                                webView.reload();
                                timer.cancel();
                            }
                        }

                        @Override
                        public void onFinish() {

                        }
                    }.start();
                }

                return;
            }

            i = 0;

            progressBar.setProgress(newProgress);

            if (newProgress == 100) {

                progressBar.setVisibility(View.INVISIBLE);

            } else {

                progressBar.setVisibility(View.VISIBLE);
            }

            super.onProgressChanged(view, newProgress);
        }
    }

    private boolean isNotNetworkAvailable() {

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return (!(activeNetworkInfo != null && activeNetworkInfo.isConnected()));
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

}